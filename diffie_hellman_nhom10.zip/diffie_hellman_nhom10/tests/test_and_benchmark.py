"""
Module Kiểm thử (Test Suite) & Đo thời gian chạy (Benchmark) cho hệ mã Diffie–Hellman (Nhóm 10).
Tái hiện chính xác toàn bộ các Bài tập Ví dụ (BTVD) trong Slide Chương 3 của ThS. Nguyễn Quốc Thái:

1. Ca kiểm thử TC-01 (BTVD Diffie–Hellman trên lớp - Slide 51):
   - Tham số: q = 353, α = 3, x_A = 97, x_B = 233
   - Kết quả: y_A = 3^97 mod 353 = 40; y_B = 3^233 mod 353 = 248; K_AB = 248^97 mod 353 = 40^233 mod 353 = 160.
2. Ca kiểm thử TC-02 (Các BTVD toán học nền tảng trong Slide Chương 3):
   - Slide 14 & 16: GCD(4864, 3458) = 38 và Euclide mở rộng: 4864 * 32 + 3458 * (-45) = 38.
   - Slide 21 (BTVD 1): 25^(-1) mod 101 = 97 (bảng 6 cột).
   - Slide 22 (BTVD 2): 173^(-1) mod 1024 = 805 (bảng 6 cột).
   - Slide 24 (BTVD 3): Bình phương và nhân 7^560 mod 561 = 1 (bảng i, b_i, c, f).
3. Ca kiểm thử TC-03: Bộ số siêu nhỏ q = 23, α = 5, x_A = 6, x_B = 15 => y_A = 8, y_B = 19, K_AB = 2.
4. Ca kiểm thử TC-04: Mã hoá & Giải mã văn bản tiếng Việt UTF-8 và tệp dữ liệu thật (.txt, .png).
5. Ca kiểm thử TC-05: Tấn công Người đứng giữa (Man-in-the-Middle) trên bộ số Slide 51 (q=353, α=3) và phòng chống bằng chữ ký số RSA.
6. Ca đối chiếu chuẩn STD-01: RFC 3526 MODP Group 14 (2048-bit) đối chiếu với hàm pow() chuẩn của Python.
7. Ca đối chiếu chuẩn STD-02: NIST FIPS 180-4 SHA-256 đối chiếu với hashlib.sha256.
"""

import hashlib
import os
import struct
import sys
import time
import zlib
from typing import Dict, List

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from core import (
    RFC3526_GROUP14_G,
    RFC3526_GROUP14_P,
    baby_step_giant_step,
    custom_sha256,
    decrypt_bytes,
    encrypt_bytes,
    encrypt_decrypt_file_demo,
    encrypt_decrypt_text_demo,
    extended_gcd,
    mod_exp,
    mod_inverse_table,
    run_full_dh_exchange,
    run_tiny_dh_exchange,
    simulate_mitm_attack,
    simulate_mitm_defense_authenticated_dh,
    square_and_multiply,
)


def ensure_sample_files() -> Dict[str, str]:
    """Tạo sẵn tệp văn bản .txt và tệp ảnh .png thật trong sample_data/ để chạy demo và kiểm thử."""
    sample_dir = os.path.join(ROOT_DIR, "sample_data")
    os.makedirs(sample_dir, exist_ok=True)

    txt_path = os.path.join(sample_dir, "thong_diep_nhom10.txt")
    txt_content = (
        "============================================================\n"
        "BÀI TẬP NHÓM: AN TOÀN VÀ BẢO MẬT THÔNG TIN (TMDT CLC - C)\n"
        "Giảng viên hướng dẫn: ThS. Nguyễn Quốc Thái\n"
        "Đề tài: Trao đổi khoá Diffie – Hellman (Nhóm 10)\n"
        "Ví dụ chuẩn trên lớp (Slide 51 Chương 3):\n"
        "  q = 353, alpha = 3, x_A = 97, x_B = 233\n"
        "  => y_A = 40, y_B = 248, Khoá phiên chung K_AB = 160\n"
        "Thành viên Nhóm 10:\n"
        "  1. Nguyễn Trung Kiên    - MSSV: 11244089\n"
        "  2. Bùi Trần Linh Hương  - MSSV: 11245586\n"
        "  3. Phạm Minh Dung       - MSSV: 11241333\n"
        "  4. Tạ Huyền Trang       - MSSV: 11240133\n"
        "  5. Phùng Trà My         - MSSV: 11242778\n"
        "============================================================\n"
    )
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(txt_content)

    png_path = os.path.join(sample_dir, "logo_nhom10.png")
    width, height = 64, 64
    raw_rows = bytearray()
    for y in range(height):
        raw_rows.append(0)
        for x in range(width):
            r = (x * 4) & 0xFF
            g_col = (y * 4) & 0xFF
            b_col = ((x + y) * 2) & 0xFF
            raw_rows.extend((r, g_col, b_col))

    def make_png_chunk(chunk_type: bytes, data: bytes) -> bytes:
        crc = zlib.crc32(chunk_type + data) & 0xFFFFFFFF
        return struct.pack(">I", len(data)) + chunk_type + data + struct.pack(">I", crc)

    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    compressed = zlib.compress(bytes(raw_rows), 9)
    png_bytes = (
        b"\x89PNG\r\n\x1a\n"
        + make_png_chunk(b"IHDR", ihdr)
        + make_png_chunk(b"IDAT", compressed)
        + make_png_chunk(b"IEND", b"")
    )
    with open(png_path, "wb") as f:
        f.write(png_bytes)

    return {"txt_path": txt_path, "png_path": png_path, "sample_dir": sample_dir}


def run_all_tests() -> Dict:
    """Chạy toàn bộ các ca kiểm thử tái hiện ví dụ trên lớp (Slide Chương 3) và đối chiếu chuẩn."""
    files = ensure_sample_files()
    sample_dir = files["sample_dir"]
    results: List[Dict] = []

    # -------------------------------------------------------------------------
    # CA KIỂM THỬ 1: TÁI HIỆN ĐÚNG BTVD DIFFIE-HELLMAN TRÊN LỚP (SLIDE 51 CHƯƠNG 3)
    # q = 353, α = 3, x_A = 97, x_B = 233 => y_A = 40, y_B = 248, K_AB = 160
    # -------------------------------------------------------------------------
    slide51_res = run_tiny_dh_exchange(p=353, g=3, a=97, b=233)
    tc1_passed = (
        slide51_res["alice"]["y_A"] == 40
        and slide51_res["bob"]["y_B"] == 248
        and slide51_res["alice"]["K_AB"] == 160
        and slide51_res["bob"]["K_AB"] == 160
        and slide51_res["verification"]["stdlib_pow_match"]
    )
    results.append({
        "id": "TC-01",
        "category": "Ví dụ trên lớp (Slide 51 Chương 3)",
        "name": "BTVD Diffie–Hellman trên lớp: q=353, α=3, x_A=97, x_B=233",
        "expected": "y_A = 40, y_B = 248, K_AB = 160 (khớp Slide 51 & pow() chuẩn)",
        "actual": (
            f"y_A = {slide51_res['alice']['y_A']}, "
            f"y_B = {slide51_res['bob']['y_B']}, "
            f"K_AB(A) = {slide51_res['alice']['K_AB']}, "
            f"K_AB(B) = {slide51_res['bob']['K_AB']}"
        ),
        "passed": tc1_passed,
    })

    # -------------------------------------------------------------------------
    # CA KIỂM THỬ 2: TÁI HIỆN CÁC BTVD TOÁN HỌC NỀN TẢNG TRONG SLIDE CHƯƠNG 3
    # (Slide 16: GCD(4864,3458)=38; Slide 21: 25^-1 mod 101=97; Slide 22: 173^-1 mod 1024=805; Slide 24: 7^560 mod 561=1)
    # -------------------------------------------------------------------------
    d_16, x_16, y_16, _ = extended_gcd(4864, 3458, trace=True)
    inv_21, rows_21 = mod_inverse_table(25, 101)
    inv_22, rows_22 = mod_inverse_table(173, 1024)
    f_24, trace_24 = square_and_multiply(7, 560, 561, trace=True)
    tc2_passed = (
        (d_16 == 38 and x_16 == 32 and y_16 == -45)
        and (inv_21 == 97 and len(rows_21) == 2)
        and (inv_22 == 805 and len(rows_22) == 6)
        and (f_24 == 1 and trace_24[-1]["c"] == 560)
    )
    results.append({
        "id": "TC-02",
        "category": "Ví dụ trên lớp (Slide 16, 21, 22, 24)",
        "name": "Kiểm thử Euclide mở rộng, Nghịch đảo 6 cột & Bình phương và nhân trên lớp",
        "expected": "GCD=38 (32,-45); 25⁻¹=97; 173⁻¹=805; 7^560 mod 561 = 1",
        "actual": f"GCD={d_16} ({x_16},{y_16}); 25⁻¹={inv_21}; 173⁻¹={inv_22}; 7^560 mod 561={f_24}",
        "passed": tc2_passed,
    })

    # -------------------------------------------------------------------------
    # CA KIỂM THỬ 3: BỘ SỐ NHỎ TÍNH NHẨM (q=23, α=5, x_A=6, x_B=15) & GIẢI DLP
    # -------------------------------------------------------------------------
    tiny23 = run_tiny_dh_exchange(p=23, g=5, a=6, b=15)
    bsgs_353 = baby_step_giant_step(3, 40, 353)
    tc3_passed = (
        tiny23["alice"]["y_A"] == 8
        and tiny23["bob"]["y_B"] == 19
        and tiny23["alice"]["K_AB"] == 2
        and bsgs_353["found"]
        and bsgs_353["x"] == 97
    )
    results.append({
        "id": "TC-03",
        "category": "Tự viết (Tính tay & Phá mã DLP)",
        "name": "Bộ số nhỏ (q=23, α=5) & Giải Logarit rời rạc tìm x_A=97 từ 3^x ≡ 40 mod 353",
        "expected": "q=23 -> K_AB=2; Baby-step Giant-step tìm đúng x_A = 97",
        "actual": f"q=23 -> K_AB={tiny23['alice']['K_AB']}; BSGS tìm được x_A = {bsgs_353['x']} sau {bsgs_353['total_ops']} bước",
        "passed": tc3_passed,
    })

    # -------------------------------------------------------------------------
    # CA KIỂM THỬ 4: MÃ HOÁ & GIẢI MÃ VĂN BẢN TIẾNG VIỆT & TỆP DỮ LIỆU THẬT (.TXT, .PNG)
    # BẰNG KHOÁ PHIÊN CHUNG K_AB = 160 CỦA VÍ DỤ TRÊN LỚP
    # -------------------------------------------------------------------------
    shared_k = slide51_res["alice"]["K_AB"]  # K_AB = 160
    sample_msg = "Khoá phiên K_AB = 160 (Slide 51) mã hoá thành công văn bản tiếng Việt!"
    text_demo = encrypt_decrypt_text_demo(sample_msg, shared_k, shared_k)
    txt_demo = encrypt_decrypt_file_demo(
        files["txt_path"],
        os.path.join(sample_dir, "thong_diep_nhom10.enc"),
        os.path.join(sample_dir, "thong_diep_nhom10_recovered.txt"),
        shared_k,
        shared_k,
    )
    png_demo = encrypt_decrypt_file_demo(
        files["png_path"],
        os.path.join(sample_dir, "logo_nhom10.enc"),
        os.path.join(sample_dir, "logo_nhom10_recovered.png"),
        shared_k,
        shared_k,
    )
    tc4_passed = (
        text_demo["exact_match"]
        and txt_demo["byte_for_byte_match"]
        and png_demo["byte_for_byte_match"]
    )
    results.append({
        "id": "TC-04",
        "category": "Tự viết (Dữ liệu thật .txt & .png)",
        "name": "Mã hoá & Giải mã UTF-8, tệp .txt và ảnh .png bằng K_AB = 160",
        "expected": "Khôi phục đúng 100% văn bản tiếng Việt, tệp .txt và ảnh .png",
        "actual": (
            f"UTF-8: {text_demo['exact_match']} | "
            f"TXT ({txt_demo['original_size_bytes']}B): {txt_demo['byte_for_byte_match']} | "
            f"PNG ({png_demo['original_size_bytes']}B): {png_demo['byte_for_byte_match']}"
        ),
        "passed": tc4_passed,
    })

    # -------------------------------------------------------------------------
    # CA KIỂM THỬ 5: MÔ PHỎNG TẤN CÔNG MAN-IN-THE-MIDDLE & PHÒNG CHỐNG BẰNG CHỮ KÝ RSA
    # TRÊN BỘ THAM SỐ BÀI GIẢNG (q = 353, α = 3, x_A = 97, x_B = 233)
    # -------------------------------------------------------------------------
    mitm_res = simulate_mitm_attack(p=353, g=3, a=97, b=233, e1=45, e2=112)
    def_res = simulate_mitm_defense_authenticated_dh(p=353, g=3, a=97, b=233, e1=45)
    tc5_passed = (
        mitm_res["attack_succeeded"]
        and def_res["eve_attack_attempt"]["attack_blocked"]
        and def_res["authenticated_channel_result"]["legit_signature_verified"]
    )
    results.append({
        "id": "TC-05",
        "category": "Tự viết (An toàn & Phòng chống MitM)",
        "name": "Tấn công Người đứng giữa (Eve) trên (q=353, α=3) & Chặn bằng chữ ký RSA",
        "expected": "Không xác thực -> Eve đọc/sửa tin (K_AE=294, K_BE=89); Có RSA -> Chặn Eve",
        "actual": (
            f"MitM thành công: {mitm_res['attack_succeeded']} (K_AE={mitm_res['shared_secrets']['K_Alice_Eve']}, "
            f"K_BE={mitm_res['shared_secrets']['K_Bob_Eve']}) | RSA chặn Eve: {def_res['eve_attack_attempt']['attack_blocked']}"
        ),
        "passed": tc5_passed,
    })

    # -------------------------------------------------------------------------
    # CA KIỂM THỬ 6 (ĐỐI CHIẾU CHUẨN 1): RFC 3526 GROUP 14 (2048-BIT MODP) VS PYTHON POW()
    # -------------------------------------------------------------------------
    a_rfc = int(
        "A1B2C3D4E5F60718293A4B5C6D7E8F90112233445566778899AABBCCDDEEFF01", 16
    )
    b_rfc = int(
        "F0E1D2C3B4A5968778695A4B3C2D1E0F99887766554433221100FFEEDDCCBBAA", 16
    )
    rfc_res = run_full_dh_exchange(mode="rfc3526_2048", a=a_rfc, b=b_rfc)
    std_K_rfc = pow(
        pow(RFC3526_GROUP14_G, b_rfc, RFC3526_GROUP14_P), a_rfc, RFC3526_GROUP14_P
    )
    tc6_passed = (
        rfc_res["shared_secret_int"] == std_K_rfc
        and rfc_res["verification"]["stdlib_pow_match"]
    )
    results.append({
        "id": "STD-01",
        "category": "Đối chiếu chuẩn RFC 3526 & Python pow()",
        "name": "RFC 3526 MODP Group 14 (2048-bit) đối chiếu với hàm pow() chuẩn",
        "expected": f"K[0..16] = {hex(std_K_rfc)[2:18].upper()}...",
        "actual": f"K[0..16] = {rfc_res['shared_secret_hex'][:16]}... (Khớp tuyệt đối 2048-bit)",
        "passed": tc6_passed,
    })

    # -------------------------------------------------------------------------
    # CA KIỂM THỬ 7 (ĐỐI CHIẾU CHUẨN 2): NIST FIPS 180-4 SHA-256 TEST VECTORS VS HASHLIB
    # -------------------------------------------------------------------------
    nist_vectors = [
        (
            b"abc",
            "BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD",
        ),
        (
            b"",
            "E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855",
        ),
        (
            b"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
            "248D6A61D20638B8E5C026930C3E6039A33CE45964FF2167F6ECEDD419DB06C1",
        ),
    ]
    all_nist_ok = True
    for msg_bytes, expected_hex in nist_vectors:
        our_hex = custom_sha256(msg_bytes).hex().upper()
        stdlib_hex = hashlib.sha256(msg_bytes).hexdigest().upper()
        if our_hex != expected_hex or our_hex != stdlib_hex:
            all_nist_ok = False
            break

    results.append({
        "id": "STD-02",
        "category": "Đối chiếu chuẩn NIST FIPS 180-4 & hashlib",
        "name": "Kiểm thử hàm băm tự viết custom_sha256 với 3 bộ NIST Test Vectors",
        "expected": "Khớp 100% với NIST FIPS 180-4 và hashlib.sha256 của Python",
        "actual": f"Khớp cả 3 vector chuẩn NIST ('abc', chuỗi rỗng, chuỗi 448-bit): {all_nist_ok}",
        "passed": all_nist_ok,
    })

    passed_count = sum(1 for r in results if r["passed"])
    return {
        "total_tests": len(results),
        "passed_tests": passed_count,
        "all_passed": passed_count == len(results),
        "test_cases": results,
        "file_demo_details": {"txt": txt_demo, "png": png_demo},
    }


def run_benchmarks() -> Dict:
    """
    Đo thời gian thực thi (Benchmark):
    1. Thời gian tính trao đổi khoá Diffie–Hellman theo độ dài bit của modulo nguyên tố q.
    2. Thời gian mã hoá và giải mã dữ liệu theo kích thước dữ liệu (1 KB -> 100 KB).
    """
    key_size_benchmarks = []
    bit_lengths = [16, 64, 128, 256, 512, 1024, 2048]

    for bits in bit_lengths:
        mask = (1 << bits) - 1
        p_sim = (RFC3526_GROUP14_P & mask) | (1 << (bits - 1)) | 1
        g_sim = 3
        exp_bits = min(256, max(12, bits - 2))
        a_sim = (1 << (exp_bits - 1)) | 0x5A5A5
        b_sim = (1 << (exp_bits - 1)) | 0x3C3C3

        t0 = time.perf_counter()
        A = mod_exp(g_sim, a_sim, p_sim)
        B = mod_exp(g_sim, b_sim, p_sim)
        K_A = mod_exp(B, a_sim, p_sim)
        K_B = mod_exp(A, b_sim, p_sim)
        custom_ms = (time.perf_counter() - t0) * 1000.0

        t1 = time.perf_counter()
        std_A = pow(g_sim, a_sim, p_sim)
        std_B = pow(g_sim, b_sim, p_sim)
        std_KA = pow(std_B, a_sim, p_sim)
        std_KB = pow(std_A, b_sim, p_sim)
        stdlib_ms = (time.perf_counter() - t1) * 1000.0

        key_size_benchmarks.append({
            "p_bits": bits,
            "exponent_bits": exp_bits,
            "custom_square_multiply_ms": round(custom_ms, 4),
            "python_stdlib_pow_ms": round(stdlib_ms, 4),
            "match": (K_A == K_B == std_KA == std_KB),
        })

    data_size_benchmarks = []
    sizes_kb = [1, 5, 10, 25, 50, 100]
    shared_secret = 160

    for kb in sizes_kb:
        payload = os.urandom(kb * 1024)
        enc = encrypt_bytes(payload, shared_secret, nonce=b"BENCHMRK")
        dec = decrypt_bytes(enc["packet_bytes"], shared_secret)
        data_size_benchmarks.append({
            "size_kb": kb,
            "size_bytes": kb * 1024,
            "encrypt_ms": enc["elapsed_ms"],
            "decrypt_ms": dec["elapsed_ms"],
            "total_ms": round(enc["elapsed_ms"] + dec["elapsed_ms"], 4),
            "integrity_ok": dec["integrity_verified"] and (dec["recovered_bytes"] == payload),
        })

    return {
        "key_size_benchmarks": key_size_benchmarks,
        "data_size_benchmarks": data_size_benchmarks,
    }


if __name__ == "__main__":
    print("=" * 80)
    print("BỘ KIỂM THỬ & ĐỐI CHIẾU HỆ MÃ TRAO ĐỔI KHOÁ DIFFIE–HELLMAN (NHÓM 10)")
    print("=" * 80)
    suite = run_all_tests()
    for tc in suite["test_cases"]:
        status = "[PASS - ĐẠT]" if tc["passed"] else "[FAIL - LỖI]"
        print(f"{status} {tc['id']} ({tc['category']}): {tc['name']}")
        print(f"       Kỳ vọng : {tc['expected']}")
        print(f"       Thực tế : {tc['actual']}\n")
    print(f"=> TỔNG KẾT KIỂM THỬ: {suite['passed_tests']}/{suite['total_tests']} ca kiểm thử ĐẠT 100%.\n")
