"""
Module Dẫn xuất khoá & Mã hoá/Giải mã dữ liệu thật từ khoá chung Diffie–Hellman (Nhóm 10).

Vì bản thân giao thức Diffie–Hellman chỉ thiết lập một khoá bí mật chung K = g^(ab) mod p
giữa Alice và Bob, để truyền bản rõ (văn bản tiếng Việt hoặc tệp ảnh/tài liệu thật) qua
kênh truyền và giải mã ngược lại, ta cần:
1. Hàm băm mật mã SHA-256 tự cài đặt từ đầu (theo chuẩn NIST FIPS 180-4, cấu trúc
   Merkle–Damgård, 64 vòng nén) để dẫn xuất khoá đối xứng 256-bit từ khoá chung K
   mà không phụ thuộc vào thư viện ngoài. (Hàm hashlib.sha256 chuẩn chỉ dùng để đối chiếu).
2. Chế độ mã hoá dòng Counter/Keystream (KDF-SHA256-CTR) kết hợp mã xác thực thông điệp
   (MAC) để mã hoá và giải mã cả chuỗi văn bản lẫn tệp nhị phân (.txt, .png, .bmp...)
   khôi phục đúng 100% bản rõ ban đầu.
"""

import hashlib
import os
import struct
import time
from typing import Dict, Tuple

# ============================================================================
# 1. CÀI ĐẶT HÀM BĂM SHA-256 TỪ ĐẦU (CHUẨN NIST FIPS 180-4)
# ============================================================================

# 8 giá trị băm khởi tạo H0..H7 (32 bit đầu phần thập phân căn bậc hai của 8 số nguyên tố đầu)
SHA256_H0 = [
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
    0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19,
]

# 64 hằng số vòng K[0..63] (32 bit đầu phần thập phân căn bậc ba của 64 số nguyên tố đầu)
SHA256_K = [
    0x428A2F98, 0x71374491, 0xB5C0FBCF, 0xE9B5DBA5, 0x3956C25B, 0x59F111F1, 0x923F82A4, 0xAB1C5ED5,
    0xD807AA98, 0x12835B01, 0x243185BE, 0x550C7DC3, 0x72BE5D74, 0x80DEB1FE, 0x9BDC06A7, 0xC19BF174,
    0xE49B69C1, 0xEFBE4786, 0x0FC19DC6, 0x240CA1CC, 0x2DE92C6F, 0x4A7484AA, 0x5CB0A9DC, 0x76F988DA,
    0x983E5152, 0xA831C66D, 0xB00327C8, 0xBF597FC7, 0xC6E00BF3, 0xD5A79147, 0x06CA6351, 0x14292967,
    0x27B70A85, 0x2E1B2138, 0x4D2C6DFC, 0x53380D13, 0x650A7354, 0x766A0ABB, 0x81C2C92E, 0x92722C85,
    0xA2BFE8A1, 0xA81A664B, 0xC24B8B70, 0xC76C51A3, 0xD192E819, 0xD6990624, 0xF40E3585, 0x106AA070,
    0x19A4C116, 0x1E376C08, 0x2748774C, 0x34B0BCB5, 0x391C0CB3, 0x4ED8AA4A, 0x5B9CCA4F, 0x682E6FF3,
    0x748F82EE, 0x78A5636F, 0x84C87814, 0x8CC70208, 0x90BEFFFA, 0xA4506CEB, 0xBEF9A3F7, 0xC67178F2,
]


def _rotr32(x: int, n: int) -> int:
    """Phép dịch vòng phải 32-bit: ROTR^n(x)."""
    return ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF


def custom_sha256(data: bytes) -> bytes:
    """
    Hàm băm SHA-256 tự cài đặt từ đầu (không gọi hashlib.sha256).
    Trả về chuỗi 32 byte (256 bit).
    """
    msg = bytearray(data)
    orig_bit_len = (8 * len(msg)) & 0xFFFFFFFFFFFFFFFF

    # Bước 1: Đệm bit 1 (0x80) và các bit 0 sao cho độ dài ≡ 56 (mod 64)
    msg.append(0x80)
    while len(msg) % 64 != 56:
        msg.append(0x00)

    # Đệm 8 byte độ dài ban đầu theo thứ tự Big-Endian
    msg += struct.pack(">Q", orig_bit_len)

    h0, h1, h2, h3, h4, h5, h6, h7 = SHA256_H0

    # Bước 2: Xử lý từng khối 512-bit (64 byte)
    for offset in range(0, len(msg), 64):
        chunk = msg[offset : offset + 64]
        w = list(struct.unpack(">16L", chunk)) + [0] * 48

        for i in range(16, 64):
            s0 = _rotr32(w[i - 15], 7) ^ _rotr32(w[i - 15], 18) ^ (w[i - 15] >> 3)
            s1 = _rotr32(w[i - 2], 17) ^ _rotr32(w[i - 2], 19) ^ (w[i - 2] >> 10)
            w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & 0xFFFFFFFF

        a, b, c, d, e, f, g, h = h0, h1, h2, h3, h4, h5, h6, h7

        for i in range(64):
            S1 = _rotr32(e, 6) ^ _rotr32(e, 11) ^ _rotr32(e, 25)
            ch = (e & f) ^ ((~e) & g)
            temp1 = (h + S1 + ch + SHA256_K[i] + w[i]) & 0xFFFFFFFF
            S0 = _rotr32(a, 2) ^ _rotr32(a, 13) ^ _rotr32(a, 22)
            maj = (a & b) ^ (a & c) ^ (b & c)
            temp2 = (S0 + maj) & 0xFFFFFFFF

            h = g
            g = f
            f = e
            e = (d + temp1) & 0xFFFFFFFF
            d = c
            c = b
            b = a
            a = (temp1 + temp2) & 0xFFFFFFFF

        h0 = (h0 + a) & 0xFFFFFFFF
        h1 = (h1 + b) & 0xFFFFFFFF
        h2 = (h2 + c) & 0xFFFFFFFF
        h3 = (h3 + d) & 0xFFFFFFFF
        h4 = (h4 + e) & 0xFFFFFFFF
        h5 = (h5 + f) & 0xFFFFFFFF
        h6 = (h6 + g) & 0xFFFFFFFF
        h7 = (h7 + h) & 0xFFFFFFFF

    return struct.pack(">8L", h0, h1, h2, h3, h4, h5, h6, h7)


def derive_session_key(shared_secret_k: int) -> Tuple[bytes, str, bool]:
    """
    Dẫn xuất khoá phiên 256-bit từ khoá bí mật chung K = g^(ab) mod p
    bằng hàm custom_sha256 tự viết, đồng thời đối chiếu với hashlib.sha256 chuẩn.
    """
    k_bytes = str(shared_secret_k).encode("utf-8")
    session_key = custom_sha256(k_bytes)
    stdlib_key = hashlib.sha256(k_bytes).digest()
    return session_key, session_key.hex().upper(), (session_key == stdlib_key)


# ============================================================================
# 2. MÃ HOÁ & GIẢI MÃ DÒNG KHOÁ (KEYSTREAM CTR) CHO VĂN BẢN & TỆP THẬT
# ============================================================================

def _generate_keystream(session_key: bytes, nonce: bytes, length: int) -> bytes:
    """
    Sinh dòng khoá (Keystream) có độ dài `length` byte từ `session_key` (32 byte)
    và `nonce` (8 byte) theo chế độ bộ đếm (Counter Mode) dựa trên custom_sha256.
    """
    out = bytearray()
    counter = 0
    while len(out) < length:
        block_input = session_key + nonce + struct.pack(">Q", counter)
        out.extend(custom_sha256(block_input))
        counter += 1
    return bytes(out[:length])


def compute_mac(session_key: bytes, nonce: bytes, ciphertext: bytes) -> bytes:
    """Tính mã xác thực thông điệp (MAC 16 byte đầu) để kiểm tra tính toàn vẹn khi giải mã."""
    return custom_sha256(b"DH-MAC-V1|" + session_key + nonce + ciphertext)[:16]


def encrypt_bytes(plaintext: bytes, shared_secret_k: int, nonce: bytes = None) -> Dict:
    """
    Mã hoá mảng byte bất kỳ (văn bản hoặc tệp ảnh/dữ liệu thật) bằng khoá chung K.
    Gói bản mã gồm: [8 byte Nonce] + [16 byte MAC] + [Ciphertext].
    """
    t0 = time.perf_counter()
    session_key, session_key_hex, kdf_verified = derive_session_key(shared_secret_k)
    if nonce is None:
        nonce = os.urandom(8)
    elif len(nonce) != 8:
        nonce = custom_sha256(nonce)[:8]

    keystream = _generate_keystream(session_key, nonce, len(plaintext))
    ciphertext = bytes(p_b ^ k_b for p_b, k_b in zip(plaintext, keystream))
    mac = compute_mac(session_key, nonce, ciphertext)
    packet = nonce + mac + ciphertext
    elapsed_ms = (time.perf_counter() - t0) * 1000.0

    return {
        "shared_secret_k": shared_secret_k,
        "session_key_hex": session_key_hex,
        "kdf_matches_stdlib": kdf_verified,
        "nonce_hex": nonce.hex().upper(),
        "mac_hex": mac.hex().upper(),
        "ciphertext_bytes": ciphertext,
        "ciphertext_hex": ciphertext.hex().upper(),
        "packet_bytes": packet,
        "packet_hex": packet.hex().upper(),
        "keystream_preview_hex": keystream[:32].hex().upper(),
        "plaintext_size_bytes": len(plaintext),
        "packet_size_bytes": len(packet),
        "elapsed_ms": round(elapsed_ms, 4),
    }


def decrypt_bytes(packet: bytes, shared_secret_k: int) -> Dict:
    """
    Giải mã gói dữ liệu [8 byte Nonce + 16 byte MAC + Ciphertext] bằng khoá chung K.
    Kiểm tra tính toàn vẹn bằng MAC trước khi khôi phục bản rõ.
    """
    t0 = time.perf_counter()
    if len(packet) < 24:
        raise ValueError("Gói bản mã không hợp lệ (nhỏ hơn 24 byte header Nonce + MAC).")

    nonce = packet[:8]
    mac_received = packet[8:24]
    ciphertext = packet[24:]

    session_key, session_key_hex, _ = derive_session_key(shared_secret_k)
    mac_expected = compute_mac(session_key, nonce, ciphertext)
    integrity_ok = mac_received == mac_expected

    keystream = _generate_keystream(session_key, nonce, len(ciphertext))
    recovered_bytes = bytes(c_b ^ k_b for c_b, k_b in zip(ciphertext, keystream))
    elapsed_ms = (time.perf_counter() - t0) * 1000.0

    return {
        "integrity_verified": integrity_ok,
        "session_key_hex": session_key_hex,
        "nonce_hex": nonce.hex().upper(),
        "mac_received_hex": mac_received.hex().upper(),
        "mac_expected_hex": mac_expected.hex().upper(),
        "recovered_bytes": recovered_bytes,
        "recovered_size_bytes": len(recovered_bytes),
        "elapsed_ms": round(elapsed_ms, 4),
    }


def encrypt_decrypt_text_demo(
    plaintext_str: str, shared_secret_alice: int, shared_secret_bob: int
) -> Dict:
    """
    Demo hai chiều hoàn chỉnh:
    - Alice mã hoá chuỗi văn bản UTF-8 bằng khoá K_A = B^a mod p.
    - Bob giải mã bằng khoá K_B = A^b mod p và kiểm tra khớp hoàn toàn với bản rõ ban đầu.
    """
    pt_bytes = plaintext_str.encode("utf-8")
    enc = encrypt_bytes(pt_bytes, shared_secret_alice, nonce=b"DHNHOM10")
    dec = decrypt_bytes(enc["packet_bytes"], shared_secret_bob)
    recovered_text = dec["recovered_bytes"].decode("utf-8", errors="replace")

    return {
        "original_text": plaintext_str,
        "original_hex": pt_bytes.hex().upper(),
        "session_key_alice_hex": enc["session_key_hex"],
        "session_key_bob_hex": dec["session_key_hex"],
        "keystream_preview_hex": enc["keystream_preview_hex"],
        "ciphertext_hex": enc["ciphertext_hex"],
        "packet_hex": enc["packet_hex"],
        "mac_verified": dec["integrity_verified"],
        "recovered_text": recovered_text,
        "exact_match": (plaintext_str == recovered_text) and dec["integrity_verified"],
        "encrypt_ms": enc["elapsed_ms"],
        "decrypt_ms": dec["elapsed_ms"],
    }


def encrypt_decrypt_file_demo(
    input_file_path: str,
    encrypted_file_path: str,
    decrypted_file_path: str,
    shared_secret_alice: int,
    shared_secret_bob: int,
) -> Dict:
    """
    Demo mã hoá và giải mã trên tệp dữ liệu thật (tệp văn bản .txt hoặc tệp ảnh .png/.bmp).
    Kiểm tra đối chiếu SHA-256 và so sánh từng byte giữa tệp gốc và tệp sau giải mã.
    """
    with open(input_file_path, "rb") as f:
        original_bytes = f.read()

    enc_res = encrypt_bytes(original_bytes, shared_secret_alice)
    with open(encrypted_file_path, "wb") as f:
        f.write(enc_res["packet_bytes"])

    with open(encrypted_file_path, "rb") as f:
        encrypted_disk_bytes = f.read()

    dec_res = decrypt_bytes(encrypted_disk_bytes, shared_secret_bob)
    with open(decrypted_file_path, "wb") as f:
        f.write(dec_res["recovered_bytes"])

    orig_hash = custom_sha256(original_bytes).hex().upper()
    dec_hash = custom_sha256(dec_res["recovered_bytes"]).hex().upper()
    byte_match = original_bytes == dec_res["recovered_bytes"]

    return {
        "input_file": os.path.basename(input_file_path),
        "encrypted_file": os.path.basename(encrypted_file_path),
        "decrypted_file": os.path.basename(decrypted_file_path),
        "original_size_bytes": len(original_bytes),
        "encrypted_size_bytes": len(encrypted_disk_bytes),
        "decrypted_size_bytes": len(dec_res["recovered_bytes"]),
        "original_sha256": orig_hash,
        "decrypted_sha256": dec_hash,
        "mac_verified": dec_res["integrity_verified"],
        "byte_for_byte_match": byte_match,
        "encrypt_ms": enc_res["elapsed_ms"],
        "decrypt_ms": dec_res["elapsed_ms"],
    }
