"""
Module toán học nền tảng cho hệ trao đổi khoá Diffie–Hellman (Nhóm 10).
Tất cả các thuật toán đều được cài đặt từ đầu (from scratch), bám sát ký hiệu và
bảng biểu trong Slide Chương 3 (Mã hoá khoá công khai - ThS. Nguyễn Quốc Thái, ĐH KTQD):

1. Thuật toán Euclide tìm GCD (Slide 14), Euclide mở rộng (Slide 15–16) và Bảng 6 cột
   tìm phần tử nghịch đảo A^(-1) mod N (`Dòng | r0 | r1 | r2 | q | t0 | t1` - Slide 18–22).
2. Thuật toán tính A^k mod N bằng "Bình phương và nhân" (Slide 23–24):
   - Biểu diễn k dạng nhị phân b_t b_{t-1} ... b_1 b_0, chạy i từ t downto 0.
   - Ghi vết đầy đủ 4 đại lượng (i, b_i, c, f) khớp tuyệt đối với bảng trên Slide 24.
3. Thuật toán kiểm tra tính nguyên tố Miller–Rabin (Slide 29: phân tích n - 1 = 2^k * q)
   và sinh số nguyên tố an toàn.
4. Thuật toán kiểm tra và tìm căn nguyên tố / căn nguyên thuỷ α mod q (Slide 50).
5. Thuật toán giải bài toán Logarit rời rạc (Vét cạn & Bước nhỏ – Bước lớn Shanks).
"""

import math
import random
from typing import Dict, List, Optional, Tuple


# ============================================================================
# 1. THUẬT TOÁN EUCLIDE, EUCLIDE MỞ RỘNG & BẢNG NGHỊCH ĐẢO 6 CỘT (SLIDE 14–22)
# ============================================================================

def gcd(a: int, b: int) -> int:
    """Tính USCLN GCD(a, b) bằng thuật toán Euclide (Slide 14)."""
    a, b = abs(a), abs(b)
    while b != 0:
        a, b = b, a % b
    return a


def extended_gcd(a: int, b: int, trace: bool = False) -> Tuple[int, int, int, List[Dict]]:
    """
    Thuật toán Euclide mở rộng theo đúng giả mã trên Slide 15–16:
    Tìm d = UCLN(a, b) và hai số nguyên x, y thoả mãn a*x + b*y = d.
    """
    orig_a, orig_b = a, b
    if b == 0:
        return a, 1, 0, []

    x2, x1 = 1, 0
    y2, y1 = 0, 1
    steps: List[Dict] = []
    step_idx = 1

    while b > 0:
        q = a // b
        r = a - q * b
        x = x2 - q * x1
        y = y2 - q * y1
        a, b = b, r
        x2, x1 = x1, x
        y2, y1 = y1, y
        if trace:
            steps.append({
                "step": step_idx,
                "q": q,
                "r": r,
                "x": x,
                "y": y,
                "a": a,
                "b": b,
                "x2": x2,
                "x1": x1,
                "y2": y2,
                "y1": y1,
            })
        step_idx += 1

    return a, x2, y2, steps


def mod_inverse_table(a: int, n: int) -> Tuple[Optional[int], List[Dict]]:
    """
    Tính phần tử nghịch đảo a^(-1) mod n theo đúng Bảng 6 cột trên Slide 18–22:
      Các cột: Dòng (row) | r0 | r1 | r2 | q | t0 | t1
      - Dòng 0: r0 = n, r1 = a, t0 = 0, t1 = 1
      - Trên dòng i: r2 = r0 mod r1, q = ⌊r0 / r1⌋
      - Khi chuyển sang dòng tiếp theo:
          r0_mới = r1_cũ, r1_mới = r2_cũ, t0_mới = t1_cũ,
          t1_mới = (t0_cũ - q_cũ * t1_cũ) mod n
      - Dừng khi r2 = 0: nếu r1 = 1 thì kết quả nghịch đảo là t1 của dòng đang xét.
    """
    r0 = n
    r1 = a % n
    t0 = 0
    t1 = 1
    rows: List[Dict] = []
    row_idx = 0

    if r1 == 0:
        return None, rows

    while True:
        r2 = r0 % r1
        q = r0 // r1
        rows.append({
            "row": row_idx,
            "r0": r0,
            "r1": r1,
            "r2": r2,
            "q": q,
            "t0": t0,
            "t1": t1,
        })
        if r2 == 0:
            if r1 == 1:
                return t1 % n, rows
            return None, rows

        next_t1 = (t0 - q * t1) % n
        r0, r1 = r1, r2
        t0, t1 = t1, next_t1
        row_idx += 1


def mod_inverse(a: int, m: int) -> int:
    """Trả về phần tử nghịch đảo a^(-1) mod m (nêu lỗi nếu không nguyên tố cùng nhau)."""
    inv, _ = mod_inverse_table(a, m)
    if inv is None:
        raise ValueError(f"Không tồn tại nghịch đảo của {a} theo modulo {m} vì USCLN({a}, {m}) != 1")
    return inv


# ============================================================================
# 2. THUẬT TOÁN "BÌNH PHƯƠNG VÀ NHÂN" (SLIDE 23–24: BẢNG i, b_i, c, f)
# ============================================================================

def square_and_multiply(
    base: int, exp: int, mod: int, trace: bool = False
) -> Tuple[int, List[Dict]]:
    """
    Tính a^k mod n bằng thuật toán "Bình phương và nhân" theo đúng giả mã Slide 23–24:
      Biểu diễn k dạng nhị phân b_t b_{t-1} ... b_1 b_0, b_i ∈ {0, 1}, 0 ≤ i ≤ t
      c ← 0; f ← 1;
      for i = t downto 0 do
          c ← 2*c
          f ← (f * f) mod n
          if b_i = 1 then
              c ← c + 1
              f ← (f * a) mod n
      return f
    """
    if mod <= 0:
        raise ValueError("Modulo phải là số nguyên dương.")
    if mod == 1:
        return 0, []
    if exp == 0:
        return 1, [{"step": 1, "i": 0, "b_i": 0, "bit": 0, "c": 0, "f": 1, "result": 1, "formula": "f = 1"}]

    bits_str = bin(exp)[2:]  # Từ MSB (b_t) xuống LSB (b_0)
    t = len(bits_str) - 1
    c = 0
    f = 1
    a_mod = base % mod
    steps: List[Dict] = []

    for step_idx, ch in enumerate(bits_str, start=1):
        i = t - (step_idx - 1)
        b_i = int(ch)
        prev_c = c
        prev_f = f

        # Bước bình phương: c <- 2*c, f <- (f * f) mod n
        c_sq = 2 * prev_c
        f_sq = (prev_f * prev_f) % mod

        if b_i == 1:
            c = c_sq + 1
            f = (f_sq * a_mod) % mod
            formula = (
                f"c = 2×{prev_c}+1 = {c}; "
                f"f = ({prev_f}² mod {mod}) × {a_mod} mod {mod} = ({f_sq} × {a_mod}) mod {mod} = {f}"
            )
        else:
            c = c_sq
            f = f_sq
            formula = f"c = 2×{prev_c} = {c}; f = {prev_f}² mod {mod} = {f}"

        if trace:
            steps.append({
                "step": step_idx,
                "i": i,
                "b_i": b_i,
                "bit": b_i,
                "prev_c": prev_c,
                "prev_f": prev_f,
                "after_square": f_sq,
                "after_multiply": f if b_i == 1 else None,
                "c": c,
                "f": f,
                "result": f,
                "formula": formula,
            })

    return f, steps


def mod_exp(base: int, exp: int, mod: int) -> int:
    """Hàm gói gọn trả về trực tiếp kết quả luỹ thừa nhanh a^k mod n."""
    res, _ = square_and_multiply(base, exp, mod, trace=False)
    return res


# ============================================================================
# 3. KIỂM TRA SỐ NGUYÊN TỐ MILLER–RABIN (SLIDE 29: n - 1 = 2^k * q)
# ============================================================================

SMALL_PRIMES = [
    2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47,
    53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113
]


def is_prime_miller_rabin(
    n: int, rounds: int = 32, trace: bool = False
) -> Tuple[bool, List[Dict]]:
    """
    Thuật toán Miller - Rabin kiểm tra tính nguyên tố của n (Slide 29):
    1. Xét các số nguyên k, q (với k > 0, q lẻ) và biểu diễn dạng: (n - 1) = 2^k * q;
    2. Chọn số nguyên a (1 < a < n - 1);
    3. Nếu a^q mod n = 1 thì n có khả năng nguyên tố;
    4. For j = 0 to k - 1 do: nếu a^(2^j * q) mod n = n - 1 thì đạt vòng kiểm tra.
    """
    trace_logs: List[Dict] = []
    if n < 2:
        return False, trace_logs
    if n in (2, 3):
        return True, [{"info": f"{n} là số nguyên tố cơ bản."}]
    if n % 2 == 0:
        return False, [{"info": f"{n} là số chẵn lớn hơn 2 -> Hợp số."}]

    # Phân tích n - 1 = 2^k * q (với q lẻ) theo đúng ký hiệu Slide 29
    q = n - 1
    k = 0
    while q % 2 == 0:
        q //= 2
        k += 1

    for sp in SMALL_PRIMES:
        if n == sp:
            if trace:
                trace_logs.append({
                    "round": 1,
                    "base_a": 2,
                    "k": k,
                    "q": q,
                    "a_pow_q_mod_n": mod_exp(2, q, n),
                    "Decomposition": f"{n} - 1 = 2^{k} × {q}",
                })
            return True, trace_logs
        if n % sp == 0:
            return False, [{"info": f"{n} chia hết cho {sp} -> Hợp số."}]

    rng = random.SystemRandom()
    deterministic_bases = [2, 3, 5, 7, 11, 13, 17, 19, 23]
    for round_idx in range(1, rounds + 1):
        if round_idx <= len(deterministic_bases) and deterministic_bases[round_idx - 1] < n - 1:
            a = deterministic_bases[round_idx - 1]
        else:
            a = rng.randrange(2, n - 1)

        x = mod_exp(a, q, n)
        if trace and round_idx <= 4:
            trace_logs.append({
                "round": round_idx,
                "base_a": a,
                "k": k,
                "q": q,
                "a_pow_q_mod_n": x,
                "Decomposition": f"{n} - 1 = 2^{k} × {q}",
            })

        if x == 1 or x == n - 1:
            continue

        passed_round = False
        for _ in range(1, k):
            x = mod_exp(x, 2, n)
            if x == n - 1:
                passed_round = True
                break
        if not passed_round:
            return False, trace_logs

    return True, trace_logs


def generate_prime(bits: int) -> int:
    """Sinh số nguyên tố ngẫu nhiên có độ dài đúng `bits` bít."""
    if bits < 4:
        raise ValueError("Số bit tối thiểu là 4.")
    rng = random.SystemRandom()
    while True:
        candidate = rng.getrandbits(bits)
        candidate |= (1 << (bits - 1)) | 1
        is_p, _ = is_prime_miller_rabin(candidate, rounds=24)
        if is_p:
            return candidate


def generate_safe_prime(bits: int) -> Tuple[int, int]:
    """Sinh số nguyên tố an toàn q = 2p' + 1."""
    if bits < 6:
        raise ValueError("Số bit cho safe prime tối thiểu là 6.")
    rng = random.SystemRandom()
    while True:
        sub_p = rng.getrandbits(bits - 1)
        sub_p |= (1 << (bits - 2)) | 1
        q = 2 * sub_p + 1
        skip = False
        for sp in SMALL_PRIMES:
            if (sub_p > sp and sub_p % sp == 0) or (q > sp and q % sp == 0):
                skip = True
                break
        if skip:
            continue
        is_sub, _ = is_prime_miller_rabin(sub_p, rounds=20)
        if not is_sub:
            continue
        is_q, _ = is_prime_miller_rabin(q, rounds=20)
        if is_q:
            return q, sub_p


# ============================================================================
# 4. KIỂM TRA & TÌM CĂN NGUYÊN TỐ / CĂN NGUYÊN THUỶ α MOD q (SLIDE 50)
# ============================================================================

def prime_factors(n: int) -> List[int]:
    """Phân tích các ước nguyên tố phân biệt của n."""
    factors: List[int] = []
    d = 2
    while d * d <= n:
        if n % d == 0:
            factors.append(d)
            while n % d == 0:
                n //= d
        d += 1 if d == 2 else 2
    if n > 1:
        factors.append(n)
    return factors


def is_primitive_root(
    alpha: int, q: int, known_factors: Optional[List[int]] = None, trace: bool = False
) -> Tuple[bool, Dict]:
    """
    Kiểm tra α có phải là căn nguyên tố (căn nguyên thuỷ) của mod q hay không (Slide 50).
    Điều kiện: Φ(q) = q - 1; với mọi ước nguyên tố p_i của Φ(q), ta có α^((q-1)/p_i) mod q != 1.
    """
    if alpha <= 1 or alpha >= q:
        return False, {"reason": f"α={alpha} nằm ngoài khoảng [2, {q-1}]"}

    phi = q - 1
    factors = known_factors if known_factors is not None else prime_factors(phi)
    factor_checks = []
    is_valid = True

    for pf in factors:
        exp = phi // pf
        rem = mod_exp(alpha, exp, q)
        passed = rem != 1
        if not passed:
            is_valid = False
        factor_checks.append({
            "prime_factor": pf,
            "exponent": exp,
            "alpha_pow_exp_mod_q": rem,
            "g_pow_exp_mod_p": rem,
            "passed": passed,
        })

    power_table = []
    distinct_values = set()
    if trace and q <= 400:
        # Lưu tối đa 60 luỹ thừa đầu tiên nếu q lớn (như q=353) hoặc toàn bộ nếu q <= 61
        limit = q if q <= 61 else 37
        for k in range(1, limit):
            val = mod_exp(alpha, k, q)
            power_table.append({"k": k, "val": val})
            distinct_values.add(val)

    return is_valid, {
        "alpha": alpha,
        "q": q,
        "g": alpha,
        "p": q,
        "phi": phi,
        "prime_factors_of_phi": factors,
        "factor_checks": factor_checks,
        "power_table": power_table,
        "distinct_count": len(distinct_values) if power_table else None,
    }


def find_primitive_root(q: int, safe_prime_sub: Optional[int] = None) -> int:
    """Tìm căn nguyên tố nhỏ nhất α của số nguyên tố q."""
    if q == 2:
        return 1
    factors = [2, safe_prime_sub] if safe_prime_sub else prime_factors(q - 1)
    for alpha in range(2, q):
        ok, _ = is_primitive_root(alpha, q, known_factors=factors, trace=False)
        if ok:
            return alpha
    raise ValueError(f"Không tìm thấy căn nguyên tố cho q = {q}")


# ============================================================================
# 5. GIẢI BÀI TOÁN LOGARIT RỜI RẠC (MINH HOẠ ĐỘ AN TOÀN - SLIDE 49–50)
# ============================================================================

def discrete_log_bruteforce(alpha: int, y: int, q: int, max_steps: int = 100000) -> Dict:
    """Giải bài toán Logarit rời rạc α^x ≡ y (mod q) bằng phương pháp vét cạn O(q)."""
    cur = 1
    a_mod = alpha % q
    limit = min(q, max_steps)
    for x in range(1, limit):
        cur = (cur * a_mod) % q
        if cur == y:
            return {"found": True, "x": x, "steps": x, "method": "Vét cạn O(q)"}
    return {"found": False, "x": None, "steps": limit, "method": "Vét cạn O(q)"}


def baby_step_giant_step(alpha: int, y: int, q: int, max_m: int = 200000) -> Dict:
    """
    Thuật toán Bước nhỏ – Bước lớn (Shanks's Baby-step Giant-step) giải α^x ≡ y (mod q)
    với độ phức tạp O(√q).
    """
    m = math.isqrt(q - 1) + 1
    if m > max_m:
        return {
            "found": False,
            "x": None,
            "m": m,
            "steps": 0,
            "reason": f"Không gian tìm kiếm √q = {m} vượt ngưỡng demo ({max_m}).",
            "method": "Baby-step Giant-step O(√q)",
        }

    table: Dict[int, int] = {}
    cur = 1
    a_mod = alpha % q
    for j in range(m):
        table[cur] = j
        cur = (cur * a_mod) % q

    alpha_inv = mod_inverse(alpha, q)
    factor = mod_exp(alpha_inv, m, q)

    gamma = y % q
    for i in range(m):
        if gamma in table:
            j = table[gamma]
            x = i * m + j
            return {
                "found": True,
                "x": x,
                "m": m,
                "baby_steps": m,
                "giant_steps": i + 1,
                "total_ops": m + i + 1,
                "i": i,
                "j": j,
                "method": "Baby-step Giant-step O(√q)",
            }
        gamma = (gamma * factor) % q

    return {
        "found": False,
        "x": None,
        "m": m,
        "total_ops": 2 * m,
        "method": "Baby-step Giant-step O(√q)",
    }
