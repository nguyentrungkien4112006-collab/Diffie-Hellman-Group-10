"""
Module cài đặt Giao thức Trao đổi khoá Diffie–Hellman (Nhóm 10).
Bám sát tuyệt đối Slide 49–51 Chương 3 (Mã hoá khoá công khai - ThS. Nguyễn Quốc Thái):

1. Phiên bản thu nhỏ / Ví dụ bài giảng trên lớp (Slide 50–51):
   - Tham số chung: Số nguyên tố q = 353 và căn nguyên tố α = 3.
   - Khoá mật ngẫu nhiên: A chọn x_A = 97, B chọn x_B = 233.
   - Khoá công khai:
       + y_A = α^(x_A) mod q = 3^97 mod 353 = 40 (của A)
       + y_B = α^(x_B) mod q = 3^233 mod 353 = 248 (của B)
   - Khoá phiên chung:
       + K_AB = y_B^(x_A) mod q = 248^97 mod 353 = 160 (do A tính)
       + K_AB = y_A^(x_B) mod q = 40^233 mod 353 = 160 (do B tính)
   - Xuất đầy đủ bảng "Bình phương và nhân" 4 hàng (i, b_i, c, f) theo đúng Slide 23–24
     cho cả 4 phép tính luỹ thừa để điền vào phần `=....=` trong Slide 51!

2. Phiên bản đầy đủ (Full Diffie–Hellman):
   - Hỗ trợ tham số chuẩn quốc tế RFC 3526 MODP Group 14 (2048-bit) và chế độ tự sinh
     số nguyên tố an toàn (64, 128, 256, 512, 1024, 2048 bit).
"""

import random
import time
from typing import Dict, Optional

from .dh_math import (
    baby_step_giant_step,
    discrete_log_bruteforce,
    find_primitive_root,
    generate_safe_prime,
    is_prime_miller_rabin,
    is_primitive_root,
    mod_exp,
    square_and_multiply,
)

# ============================================================================
# THAM SỐ CHUẨN RFC 3526 GROUP 14 (2048-BIT MODP GROUP)
# ============================================================================

RFC3526_GROUP14_P_HEX = (
    "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1"
    "29024E088A67CC74020BBEA63B139B22514A08798E3404DD"
    "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245"
    "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
    "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D"
    "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F"
    "83655D23DCA3AD961C62F356208552BB9ED529077096966D"
    "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B"
    "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9"
    "DE2BCBF6955817183995497CEA956AE515D2261898FA0510"
    "15728E5A8AACAA68FFFFFFFFFFFFFFFF"
)
RFC3526_GROUP14_P = int(RFC3526_GROUP14_P_HEX, 16)
RFC3526_GROUP14_G = 2

# Các bộ tham số mẫu cho phiên bản nhỏ (TinyDH) — Mặc định là BTVD Slide 51 trên lớp!
TINY_PRESETS = {
    "slide51_classroom": {
        "name": "BTVD chuẩn trên lớp (Slide 51): q = 353, α = 3, xA = 97, xB = 233",
        "q": 353,
        "alpha": 3,
        "xA": 97,
        "xB": 233,
    },
    "tiny_q23": {
        "name": "Bộ số siêu nhỏ tính nhẩm: q = 23, α = 5, xA = 6, xB = 15",
        "q": 23,
        "alpha": 5,
        "xA": 6,
        "xB": 15,
    },
    "tiny_q19": {
        "name": "Bộ số nhỏ 2: q = 19, α = 2, xA = 7, xB = 11",
        "q": 19,
        "alpha": 2,
        "xA": 7,
        "xB": 11,
    },
    "tiny_q97": {
        "name": "Bộ số 2 chữ số: q = 97, α = 5, xA = 36, xB = 58",
        "q": 97,
        "alpha": 5,
        "xA": 36,
        "xB": 58,
    },
}


def run_tiny_dh_exchange(
    p: int = 353, g: int = 3, a: int = 97, b: int = 233
) -> Dict:
    """
    Thực hiện giao thức Diffie–Hellman trên bộ số nhỏ (mặc định là BTVD Slide 51 trên lớp:
    q = 353, α = 3, x_A = 97, x_B = 233 => y_A = 40, y_B = 248, K_AB = 160)
    và xuất toàn bộ bảng tính tay từng bước (i, b_i, c, f) theo đúng Slide 23–24.
    Hỗ trợ đồng thời cả hai bộ tên tham số (q, α, x_A, x_B, y_A, y_B, K_AB) và (p, g, a, b, A, B, K).
    """
    q, alpha, x_A, x_B = p, g, a, b
    t0 = time.perf_counter()

    # 1. Kiểm tra tính nguyên tố của q (Miller-Rabin Slide 29) và căn nguyên tố α (Slide 50)
    is_q_prime, prime_trace = is_prime_miller_rabin(q, rounds=15, trace=True)
    if not is_q_prime:
        raise ValueError(f"Tham số q = {q} không phải là số nguyên tố!")

    is_root, root_info = is_primitive_root(alpha, q, trace=True)

    # 2. Tính khoá công khai của A: y_A = α^(x_A) mod q (kèm bảng Bình phương & Nhân Slide 24)
    y_A, trace_yA = square_and_multiply(alpha, x_A, q, trace=True)

    # 3. Tính khoá công khai của B: y_B = α^(x_B) mod q (kèm bảng Bình phương & Nhân Slide 24)
    y_B, trace_yB = square_and_multiply(alpha, x_B, q, trace=True)

    # 4. A tính khoá phiên chung: K_AB_A = y_B^(x_A) mod q
    K_AB_A, trace_KA = square_and_multiply(y_B, x_A, q, trace=True)

    # 5. B tính khoá phiên chung: K_AB_B = y_A^(x_B) mod q
    K_AB_B, trace_KB = square_and_multiply(y_A, x_B, q, trace=True)

    # 6. Đối chiếu với hàm chuẩn pow(base, exp, mod) của Python
    std_yA = pow(alpha, x_A, q)
    std_yB = pow(alpha, x_B, q)
    std_KA = pow(y_B, x_A, q)
    std_KB = pow(y_A, x_B, q)
    verified_match = (y_A == std_yA) and (y_B == std_yB) and (K_AB_A == K_AB_B == std_KA == std_KB)

    # 7. Minh hoạ giải bài toán Logarit rời rạc (tìm x_A từ α^(x_A) ≡ y_A mod q)
    dlp_bf = discrete_log_bruteforce(alpha, y_A, q)
    dlp_bsgs = baby_step_giant_step(alpha, y_A, q)

    elapsed_ms = (time.perf_counter() - t0) * 1000.0

    return {
        "mode": "TinyDH (BTVD chuẩn trên lớp - Slide 50 & 51 Chương 3)",
        "parameters": {
            "q": q,
            "alpha": alpha,
            "p": q,
            "g": alpha,
            "q_bits": q.bit_length(),
            "p_bits": q.bit_length(),
            "is_prime_q": is_q_prime,
            "is_prime_p": is_q_prime,
            "is_primitive_root_alpha": is_root,
            "is_primitive_root_g": is_root,
            "miller_rabin_trace": prime_trace,
        },
        "primitive_root_analysis": root_info,
        "alice": {
            "x_A": x_A,
            "y_A": y_A,
            "K_AB": K_AB_A,
            "private_key_a": x_A,
            "public_key_A": y_A,
            "shared_secret_KA": K_AB_A,
            "trace_A": trace_yA,
            "trace_KA": trace_KA,
        },
        "bob": {
            "x_B": x_B,
            "y_B": y_B,
            "K_AB": K_AB_B,
            "private_key_b": x_B,
            "public_key_B": y_B,
            "shared_secret_KB": K_AB_B,
            "trace_B": trace_yB,
            "trace_KB": trace_KB,
        },
        "verification": {
            "shared_secret_match": K_AB_A == K_AB_B,
            "stdlib_pow_match": verified_match,
            "std_A": std_yA,
            "std_B": std_yB,
            "std_K": std_KA,
        },
        "dlp_security_demo": {
            "target_equation": f"{alpha}^(x_A) ≡ {y_A} (mod {q})",
            "bruteforce": dlp_bf,
            "baby_step_giant_step": dlp_bsgs,
        },
        "elapsed_ms": round(elapsed_ms, 4),
    }


def run_full_dh_exchange(
    mode: str = "rfc3526_2048",
    custom_bits: int = 512,
    a: Optional[int] = None,
    b: Optional[int] = None,
) -> Dict:
    """
    Thực hiện giao thức Diffie–Hellman phiên bản đầy đủ:
    - mode="rfc3526_2048": Sử dụng bộ tham số chuẩn quốc tế RFC 3526 Group 14 (2048-bit).
    - mode="custom_safe_prime": Tự sinh số nguyên tố an toàn q = 2p' + 1 với độ dài bit tuỳ chọn.
    """
    rng = random.SystemRandom()
    t0 = time.perf_counter()

    if mode == "rfc3526_2048":
        q = RFC3526_GROUP14_P
        alpha = RFC3526_GROUP14_G
        param_source = "RFC 3526 MODP Group 14 (2048-bit Standard)"
        private_bits = 256
    else:
        q, sub_p = generate_safe_prime(custom_bits)
        alpha = find_primitive_root(q, safe_prime_sub=sub_p)
        param_source = f"Tự sinh Safe Prime q = 2p' + 1 ({custom_bits}-bit)"
        private_bits = min(256, max(16, custom_bits - 2))

    x_A = a if a is not None else rng.randrange(2, min(q - 2, 1 << private_bits))
    x_B = b if b is not None else rng.randrange(2, min(q - 2, 1 << private_bits))

    t_exchange_start = time.perf_counter()
    y_A = mod_exp(alpha, x_A, q)
    y_B = mod_exp(alpha, x_B, q)
    K_A = mod_exp(y_B, x_A, q)
    K_B = mod_exp(y_A, x_B, q)
    exchange_ms = (time.perf_counter() - t_exchange_start) * 1000.0

    std_yA = pow(alpha, x_A, q)
    std_yB = pow(alpha, x_B, q)
    std_KA = pow(y_B, x_A, q)
    std_KB = pow(y_A, x_B, q)
    verified = (y_A == std_yA) and (y_B == std_yB) and (K_A == K_B == std_KA == std_KB)

    total_ms = (time.perf_counter() - t0) * 1000.0

    return {
        "mode": "Full DH (Phiên bản đầy đủ)",
        "param_source": param_source,
        "p_bits": q.bit_length(),
        "q_bits": q.bit_length(),
        "p_hex": hex(q)[2:].upper(),
        "p_dec_preview": str(q) if q.bit_length() <= 128 else f"{str(q)[:36]}...{str(q)[-24:]} ({len(str(q))} chữ số)",
        "g": alpha,
        "alpha": alpha,
        "alice": {
            "a_bits": x_A.bit_length(),
            "a_hex": hex(x_A)[2:].upper(),
            "A_hex": hex(y_A)[2:].upper(),
            "KA_hex": hex(K_A)[2:].upper(),
        },
        "bob": {
            "b_bits": x_B.bit_length(),
            "b_hex": hex(x_B)[2:].upper(),
            "B_hex": hex(y_B)[2:].upper(),
            "KB_hex": hex(K_B)[2:].upper(),
        },
        "shared_secret_int": K_A,
        "shared_secret_hex": hex(K_A)[2:].upper(),
        "verification": {
            "shared_secret_match": K_A == K_B,
            "stdlib_pow_match": verified,
        },
        "exchange_ms": round(exchange_ms, 4),
        "total_ms": round(total_ms, 4),
    }
