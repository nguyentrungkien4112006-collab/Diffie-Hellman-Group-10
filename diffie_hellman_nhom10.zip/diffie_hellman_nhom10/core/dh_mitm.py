"""
Module Mô phỏng Tấn công Người đứng giữa (Man-in-the-Middle - MitM) và Cơ chế Phòng chống
trên giao thức Trao đổi khoá Diffie–Hellman (Nhóm 10).

Nội dung minh hoạ theo đúng yêu cầu đề tài:
1. Tấn công Người đứng giữa (MitM) trên Diffie–Hellman nguyên bản (Unauthenticated DH):
   - Vì các giá trị công khai A = g^a mod p và B = g^b mod p không gắn định danh của người gửi,
     kẻ tấn công chủ động Eve đứng giữa đường truyền có thể:
       + Chặn A của Alice, gửi E1 = g^e1 mod p cho Bob.
       + Chặn B của Bob, gửi E2 = g^e2 mod p cho Alice.
   - Kết quả:
       + Alice tính khoá chung với Eve: K_AE = (E2)^a mod p = g^(a*e2) mod p.
       + Bob tính khoá chung với Eve:   K_BE = (E1)^b mod p = g^(b*e1) mod p.
   - Khi Alice gửi bản mã cho Bob, Eve giải mã bằng K_AE để đọc trộm và sửa đổi nội dung,
     sau đó mã hoá lại bằng K_BE gửi cho Bob mà cả hai không phát hiện.

2. Cách phòng chống bằng Xác thực chữ ký số RSA (Authenticated Diffie–Hellman):
   - Alice và Bob sở hữu cặp khoá chữ ký số RSA định danh.
   - Khi gửi A, Alice đính kèm chữ ký số S_A = Hash(A)^d_Alice mod N_Alice.
   - Nếu Eve thay đổi A thành E1, chữ ký S_A sẽ không hợp lệ khi Bob kiểm tra bằng
     khoá công khai RSA của Alice -> Phát hiện và chặn đứng tấn công MitM ngay lập tức!
"""

from typing import Dict

from .dh_cipher import custom_sha256, decrypt_bytes, encrypt_bytes
from .dh_math import gcd, mod_exp, mod_inverse


# ============================================================================
# 1. MÔ PHỎNG TẤN CÔNG NGƯỜI ĐỨNG GIỮA (MAN-IN-THE-MIDDLE)
# ============================================================================

def simulate_mitm_attack(
    p: int = 23,
    g: int = 5,
    a: int = 6,
    b: int = 15,
    e1: int = 4,
    e2: int = 13,
    alice_message: str = "Chuyển khoản 50.000.000 VNĐ vào tài khoản Bob: 1903889911",
    eve_tampered_message: str = "Chuyển khoản 50.000.000 VNĐ vào tài khoản Eve: 9999666688",
) -> Dict:
    """
    Mô phỏng đầy đủ kịch bản Eve đứng giữa đánh chặn khoá công khai và sửa đổi tin nhắn.
    """
    # Bước 1: Alice và Bob tính khoá công khai của mình
    A = mod_exp(g, a, p)
    B = mod_exp(g, b, p)

    # Bước 2: Eve đứng giữa sinh 2 khoá công khai giả mạo E1 (gửi cho Bob) và E2 (gửi cho Alice)
    E1 = mod_exp(g, e1, p)  # Eve đóng giả làm Alice trước mặt Bob
    E2 = mod_exp(g, e2, p)  # Eve đóng giả làm Bob trước mặt Alice

    # Bước 3: Thiết lập 2 phiên khoá độc lập mà Alice và Bob tưởng là chung
    # Phía Alice nhận E2 (tưởng là B):
    K_Alice = mod_exp(E2, a, p)
    K_Eve_with_Alice = mod_exp(A, e2, p)

    # Phía Bob nhận E1 (tưởng là A):
    K_Bob = mod_exp(E1, b, p)
    K_Eve_with_Bob = mod_exp(B, e1, p)

    # Bước 4: Alice mã hoá tin nhắn gốc bằng K_Alice và gửi đi
    alice_enc = encrypt_bytes(alice_message.encode("utf-8"), K_Alice, nonce=b"MITMDEMO")

    # Bước 5: Eve chặn gói tin, giải mã bằng K_Eve_with_Alice để đọc trộm bản rõ
    eve_dec = decrypt_bytes(alice_enc["packet_bytes"], K_Eve_with_Alice)
    eve_intercepted_text = eve_dec["recovered_bytes"].decode("utf-8", errors="replace")

    # Bước 6: Eve sửa đổi nội dung tin nhắn, mã hoá lại bằng K_Eve_with_Bob rồi chuyển cho Bob
    eve_re_enc = encrypt_bytes(
        eve_tampered_message.encode("utf-8"), K_Eve_with_Bob, nonce=b"MITMEVE!"
    )

    # Bước 7: Bob nhận gói tin từ Eve và giải mã thành công bằng K_Bob mà không hề nghi ngờ
    bob_dec = decrypt_bytes(eve_re_enc["packet_bytes"], K_Bob)
    bob_received_text = bob_dec["recovered_bytes"].decode("utf-8", errors="replace")

    return {
        "scenario": "Tấn công Người đứng giữa (Man-in-the-Middle) khi KHÔNG xác thực",
        "parameters": {"p": p, "g": g},
        "keys": {
            "alice_private_a": a,
            "alice_public_A": A,
            "bob_private_b": b,
            "bob_public_B": B,
            "eve_private_e1": e1,
            "eve_public_E1_to_bob": E1,
            "eve_private_e2": e2,
            "eve_public_E2_to_alice": E2,
        },
        "shared_secrets": {
            "K_Alice_Eve": K_Alice,
            "K_Eve_Alice": K_Eve_with_Alice,
            "K_Bob_Eve": K_Bob,
            "K_Eve_Bob": K_Eve_with_Bob,
            "normal_K_without_attack": mod_exp(B, a, p),
        },
        "message_flow": {
            "alice_sent_plaintext": alice_message,
            "alice_ciphertext_hex": alice_enc["ciphertext_hex"],
            "eve_decrypted_plaintext": eve_intercepted_text,
            "eve_modified_plaintext": eve_tampered_message,
            "eve_re_encrypted_hex": eve_re_enc["ciphertext_hex"],
            "bob_decrypted_plaintext": bob_received_text,
        },
        "attack_succeeded": (
            K_Alice == K_Eve_with_Alice
            and K_Bob == K_Eve_with_Bob
            and eve_intercepted_text == alice_message
            and bob_received_text == eve_tampered_message
        ),
    }


# ============================================================================
# 2. CƠ CHẾ PHÒNG CHỐNG: XÁC THỰC DIFFIE–HELLMAN BẰNG CHỮ KÝ SỐ RSA
# ============================================================================

def _hash_public_value(val: int, mod_n: int) -> int:
    """Băm giá trị công khai DH bằng custom_sha256 rồi rút gọn theo modulo N_RSA."""
    digest = custom_sha256(f"DH-AUTH|{val}".encode("utf-8"))
    return (int.from_bytes(digest, "big") % (mod_n - 2)) + 1


def simulate_mitm_defense_authenticated_dh(
    p: int = 23, g: int = 5, a: int = 6, b: int = 15, e1: int = 4
) -> Dict:
    """
    Minh hoạ cách phòng chống tấn công Man-in-the-Middle bằng Chữ ký số RSA
    (Authenticated Diffie–Hellman / cơ chế nền tảng của TLS 1.3 và IKE/IPsec):
    - Alice có cặp khoá RSA định danh: (N_A, e_A) công khai, d_A bí mật.
    - Alice ký lên giá trị công khai A: sig_A = H(A)^d_A mod N_A.
    - Khi Eve chặn A và thay bằng E1 = g^e1 mod p nhưng không có khoá bí mật d_A của Alice,
      phép kiểm tra chữ ký của Bob sẽ phát hiện giả mạo ngay lập tức!
    """
    # Khởi tạo cặp khoá RSA định danh của Alice (tự cài đặt từ đầu trên 2 số nguyên tố p_rsa, q_rsa)
    p_rsa, q_rsa = 1009, 1013
    n_rsa = p_rsa * q_rsa  # 1,022,117
    phi_rsa = (p_rsa - 1) * (q_rsa - 1)
    e_rsa = 17
    while gcd(e_rsa, phi_rsa) != 1:
        e_rsa += 2
    d_rsa = mod_inverse(e_rsa, phi_rsa)

    # Bước 1: Alice tính A = g^a mod p và tạo chữ ký số RSA trên A
    A = mod_exp(g, a, p)
    hash_A = _hash_public_value(A, n_rsa)
    sig_A = mod_exp(hash_A, d_rsa, n_rsa)

    # Bước 2 (Trường hợp Eve tấn công): Eve thay A bằng E1 = g^e1 mod p
    E1 = mod_exp(g, e1, p)
    hash_E1 = _hash_public_value(E1, n_rsa)

    # Kịch bản A: Eve giữ nguyên chữ ký sig_A của Alice nhưng gửi kèm E1
    verify_hash_from_alice_sig = mod_exp(sig_A, e_rsa, n_rsa)
    tampered_detected = verify_hash_from_alice_sig != hash_E1

    # Kịch bản B: Đường truyền có xác thực hợp lệ (Alice -> Bob trực tiếp)
    legit_verified = verify_hash_from_alice_sig == hash_A
    B = mod_exp(g, b, p)
    shared_K = mod_exp(B, a, p)

    return {
        "scenario": "Phòng chống Man-in-the-Middle bằng Chữ ký số RSA (Authenticated DH)",
        "rsa_identity_key_alice": {
            "p_rsa": p_rsa,
            "q_rsa": q_rsa,
            "N_rsa": n_rsa,
            "public_exponent_e": e_rsa,
            "private_exponent_d": d_rsa,
        },
        "alice_signed_message": {
            "dh_public_A": A,
            "hash_A": hash_A,
            "rsa_signature_sigA": sig_A,
        },
        "eve_attack_attempt": {
            "eve_fake_public_E1": E1,
            "hash_E1": hash_E1,
            "bob_recovered_hash_from_sigA": verify_hash_from_alice_sig,
            "signature_match_for_E1": not tampered_detected,
            "attack_blocked": tampered_detected,
            "reason": (
                f"Bob giải mã chữ ký nhận được H(A) = {verify_hash_from_alice_sig}, "
                f"nhưng giá trị băm của khoá E1={E1} lại là H(E1) = {hash_E1} (KHÔNG KHỚP!). "
                "Bob phát hiện kẻ đứng giữa Eve và lập tức huỷ phiên trao đổi khoá!"
            ),
        },
        "authenticated_channel_result": {
            "legit_signature_verified": legit_verified,
            "established_shared_secret_K": shared_K,
        },
    }
