"""
Package core chứa các module thuật toán Trao đổi khoá Diffie–Hellman tự cài đặt từ đầu (Nhóm 10).
"""

from .dh_cipher import (
    custom_sha256,
    decrypt_bytes,
    derive_session_key,
    encrypt_bytes,
    encrypt_decrypt_file_demo,
    encrypt_decrypt_text_demo,
)
from .dh_math import (
    baby_step_giant_step,
    discrete_log_bruteforce,
    extended_gcd,
    find_primitive_root,
    gcd,
    generate_prime,
    generate_safe_prime,
    is_prime_miller_rabin,
    is_primitive_root,
    mod_exp,
    mod_inverse,
    mod_inverse_table,
    prime_factors,
    square_and_multiply,
)
from .dh_mitm import (
    simulate_mitm_attack,
    simulate_mitm_defense_authenticated_dh,
)
from .dh_protocol import (
    RFC3526_GROUP14_G,
    RFC3526_GROUP14_P,
    TINY_PRESETS,
    run_full_dh_exchange,
    run_tiny_dh_exchange,
)
